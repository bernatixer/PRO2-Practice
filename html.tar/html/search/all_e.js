var searchData=
[
  ['renombrar',['renombrar',['../_arbre_gen_8hh.html#ae50f2e7e435db649d10df7c6e50580f5',1,'ArbreGen.hh']]],
  ['reproduir',['reproduir',['../class_individu.html#a8af5f660ba954ab97e0738131e9b1b9a',1,'Individu::reproduir()'],['../class_par_crom.html#a2ad59900c0b6f38ac01066e005d250af',1,'ParCrom::reproduir()'],['../class_poblacio.html#a4ac8e32ebba13729aa7964713087734b',1,'Poblacio::reproduir()']]]
];
