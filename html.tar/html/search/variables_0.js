var searchData=
[
  ['cromosomes',['cromosomes',['../class_individu.html#ad8c2bb2e333f7ab53847067c6f8b5784',1,'Individu']]]
];
