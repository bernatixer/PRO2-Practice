var searchData=
[
  ['diff_5fsexe',['diff_sexe',['../class_poblacio.html#a8334e7c72bd10692509ec8f40b6fb109',1,'Poblacio']]]
];
