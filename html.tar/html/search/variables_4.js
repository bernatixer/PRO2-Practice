var searchData=
[
  ['mare',['mare',['../struct_poblacio_1_1_persona.html#a8b6ff7d8aa0c308cee2017b9d7dfc9a9',1,'Poblacio::Persona']]],
  ['mensaje',['mensaje',['../class_p_r_o2_excepcio.html#aa82c5df8e191f4b6134cd85d270a9e87',1,'PRO2Excepcio']]]
];
