var searchData=
[
  ['parcrom',['ParCrom',['../class_par_crom.html',1,'']]],
  ['persona',['Persona',['../struct_poblacio_1_1_persona.html',1,'Poblacio']]],
  ['poblacio',['Poblacio',['../class_poblacio.html',1,'']]],
  ['pro2excepcio',['PRO2Excepcio',['../class_p_r_o2_excepcio.html',1,'']]]
];
