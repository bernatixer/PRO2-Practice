var searchData=
[
  ['generar_5farbre_5fi',['generar_arbre_i',['../class_poblacio.html#a2304b150a6aba47a2e4b86c03e0e691c',1,'Poblacio']]]
];
