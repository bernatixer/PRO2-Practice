var searchData=
[
  ['segon',['segon',['../class_par_crom.html#ada0a3614a3b1fb2336938c8529b7d093',1,'ParCrom']]],
  ['son_5fgermans',['son_germans',['../class_poblacio.html#a2176dd24427cfbae231e9e9a7704ba25',1,'Poblacio']]],
  ['swap',['swap',['../class_arbre.html#a931d1c91e9fd6cbe72703a7ba7d40415',1,'Arbre']]]
];
