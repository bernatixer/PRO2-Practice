var searchData=
[
  ['main',['main',['../program_8cc.html#ae66f6b31b5ad750f1fe042a706a4e3d4',1,'program.cc']]],
  ['mida_5fcromosoma',['mida_cromosoma',['../class_especie.html#a41ede626be1eb09e350df7de86dfcc47',1,'Especie']]],
  ['mida_5fcromosoma_5fsexual',['mida_cromosoma_sexual',['../class_especie.html#abad2c1d6af379a2387e09d2dd56eac97',1,'Especie']]]
];
