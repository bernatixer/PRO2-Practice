var searchData=
[
  ['par_5fsexual',['par_sexual',['../class_individu.html#a75eb8ae5f22344c4c7c2d9551858bbb9',1,'Individu']]],
  ['pare',['pare',['../struct_poblacio_1_1_persona.html#ab96844afbfb48180bc78162381f74501',1,'Poblacio::Persona']]],
  ['parell',['parell',['../class_par_crom.html#ac88097f13f1d6aa34167f0f3f645be78',1,'ParCrom']]],
  ['primer_5fnode',['primer_node',['../class_arbre.html#a62818cdde6c1912a7c9a15db3b93d297',1,'Arbre']]]
];
