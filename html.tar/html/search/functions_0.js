var searchData=
[
  ['a_5fbuit',['a_buit',['../class_arbre.html#aa74ec0d2b601487b822eb70100330582',1,'Arbre']]],
  ['afegir_5findividu',['afegir_individu',['../class_poblacio.html#aebe00c7cbe14a15e7533ef5bb4510fc6',1,'Poblacio']]],
  ['antecessors',['antecessors',['../class_poblacio.html#aae152501afff41f3cfb0a9141a218e57',1,'Poblacio']]],
  ['arbre',['Arbre',['../class_arbre.html#a3f613426983169266297eb841996845e',1,'Arbre::Arbre()'],['../class_arbre.html#a8f8615c19988334f9b77dc51f44acc6d',1,'Arbre::Arbre(const Arbre &amp;original)']]],
  ['arrel',['arrel',['../class_arbre.html#a8710fa2fdbf3dee327d11344e9adaf10',1,'Arbre']]]
];
