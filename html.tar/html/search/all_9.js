var searchData=
[
  ['li',['li',['../class_especie.html#ac0c981ce50f8f9f63e2f7623fdb2d96d',1,'Especie']]],
  ['llegir',['llegir',['../class_individu.html#a1a5c2fcfdc02a9f6e1917c79ba2f1b74',1,'Individu::llegir()'],['../class_par_crom.html#a9bdc3cb63090b7562a07611f87d2aa1c',1,'ParCrom::llegir()']]],
  ['llegir_5farbre_5fgen',['llegir_arbre_gen',['../_arbre_gen_8hh.html#a8c6ac6a48519ac6e18b601afd08566b4',1,'ArbreGen.hh']]],
  ['llegir_5finformacio_5fespecie',['llegir_informacio_especie',['../class_especie.html#a5d7520734d17f01d447cfb3a31eeb389',1,'Especie']]],
  ['llegir_5fsexual',['llegir_sexual',['../class_par_crom.html#ac01fa5d4ed81f1f8373f4a1936e00afa',1,'ParCrom']]],
  ['lx',['lx',['../class_especie.html#ade4c4e0e145af39d14078b08b3b03df8',1,'Especie']]],
  ['ly',['ly',['../class_especie.html#a5d8a4e5dced433508eb01bd748c6b562',1,'Especie']]]
];
