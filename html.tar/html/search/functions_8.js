var searchData=
[
  ['llegir',['llegir',['../class_individu.html#a1a5c2fcfdc02a9f6e1917c79ba2f1b74',1,'Individu::llegir()'],['../class_par_crom.html#a9bdc3cb63090b7562a07611f87d2aa1c',1,'ParCrom::llegir()']]],
  ['llegir_5farbre_5fgen',['llegir_arbre_gen',['../_arbre_gen_8hh.html#a8c6ac6a48519ac6e18b601afd08566b4',1,'ArbreGen.hh']]],
  ['llegir_5finformacio_5fespecie',['llegir_informacio_especie',['../class_especie.html#a5d7520734d17f01d447cfb3a31eeb389',1,'Especie']]],
  ['llegir_5fsexual',['llegir_sexual',['../class_par_crom.html#ac01fa5d4ed81f1f8373f4a1936e00afa',1,'ParCrom']]]
];
