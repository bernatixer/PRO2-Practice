var searchData=
[
  ['what',['what',['../class_p_r_o2_excepcio.html#a24de68a95e8e7d4fccc147e94411d70c',1,'PRO2Excepcio']]]
];
