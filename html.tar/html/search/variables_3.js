var searchData=
[
  ['li',['li',['../class_especie.html#ac0c981ce50f8f9f63e2f7623fdb2d96d',1,'Especie']]],
  ['lx',['lx',['../class_especie.html#ade4c4e0e145af39d14078b08b3b03df8',1,'Especie']]],
  ['ly',['ly',['../class_especie.html#a5d8a4e5dced433508eb01bd748c6b562',1,'Especie']]]
];
