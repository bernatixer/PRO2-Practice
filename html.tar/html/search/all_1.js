var searchData=
[
  ['buscar_5findividu',['buscar_individu',['../class_poblacio.html#a49abb6e99b1ccef8852532db9b98d580',1,'Poblacio']]],
  ['buscar_5fpersona',['buscar_persona',['../class_poblacio.html#a18dfd17e12381b2cd0c82031e76a5a3f',1,'Poblacio']]]
];
