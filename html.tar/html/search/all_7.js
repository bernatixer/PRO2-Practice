var searchData=
[
  ['habitants',['habitants',['../class_poblacio.html#a51efba968e78a90aba4052b97e4bc988',1,'Poblacio']]]
];
